import './App.css';
import Footer from './Components/footer';
import NavMenu from './Components/navbar';
import ShopProfile from './Components/shopProfile';

function App() {
  return (
    <div className="App">
      <NavMenu />
      <ShopProfile />
      <Footer />
    </div>
  );
}

export default App;
