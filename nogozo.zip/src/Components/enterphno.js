import React from 'react';
import '../css/login.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

class EnterPhno extends React.Component{

    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="loginDiv">
                <img src="../../Images/logo.png" alt="login-img" />
                <Form>
                     <Form.Group controlId="formBasicPassword">
                          <Form.Control type="number" placeholder="Mobile Number" />
                     </Form.Group>

                    <Button variant="primary" type="submit">
                           VERIFY OTP
                    </Button>

                    <Button variant="primary" type="submit" id="btn-sign">
                           ALREADY HAVE AN ACCOUNT ?<br />
                            LOGIN
                    </Button>

                </Form>
            </div>
        );
    }
}

export default EnterPhno;