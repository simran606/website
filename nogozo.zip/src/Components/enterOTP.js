import React from 'react';
import '../css/login.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

class EnterOTP extends React.Component{

    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="loginDiv">
                <img src="../../Images/logo.png" alt="login-img" />
                <Form>
                     <Form.Group controlId="formBasicPassword">
                          <Form.Control type="number" placeholder="Enter OTP" />
                     </Form.Group>

                    <Button variant="primary" type="submit">
                           VERIFY OTP
                    </Button>

                </Form>
            </div>
        );
    }
}

export default EnterOTP;