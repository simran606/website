import React from 'react';
import '../css/login.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
// import ShopProfile from './shopProfile';
// import {Redirect} from 'react-router';


 
class Login extends React.Component{

    // state = {
    //     redirect: false
    //   }
    //   setRedirect = () => {
    //     this.setState({
    //       redirect: true
    //     })
    //   }
    //   renderRedirect = () => {
    //     if (this.state.redirect) {
    //       return <Redirect to='./register' />
    //     }
    //   }

    // constructor(props){
    //     super(props);

        
    // }

    render(){
        return(
            <div className="loginDiv">
                <img src="../../Images/logo.png" alt="login-img" />
                <Form>
                     <Form.Group controlId="formBasicEmail">
                          <Form.Control type="email" placeholder="Enter email" />
                     </Form.Group>

                     <Form.Group controlId="formBasicPassword">
                          <Form.Control type="password" placeholder="Password" />
                     </Form.Group>

                     {/* {this.renderRedirect()} */}
                     {/* onClick={this.setRedirect} */}
                     <Button  variant="primary" type="submit">
                           LOGIN
                    </Button>

                    <Button variant="primary" type="submit">
                           FORGOT PASSWORD ?
                    </Button>

                    <Button variant="primary" type="submit" id="btn-sign">
                           DON'T HAVE AN ACCOUNT ?<br />
                            SIGN UP
                    </Button>

                </Form>
            </div>
        );
    }
}

export default Login;