import React from 'react';
import Republic from './Republic';
import republicCards from './republicCard';
import NavMenuShop from './NavMenuShop';
import Footer from '../footer';

class Shop extends React.Component{
    render(){
        return(
            <div>
               <NavMenuShop />

               {republicCards.map( (item) => 
               <Republic 
               name={item.name}
               location={item.location}
               status={item.status}
               tob={item.tob}
               />
               )
               }

               <Footer />
            </div>
        );
    }
}

export default Shop;