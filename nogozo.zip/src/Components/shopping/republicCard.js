const republicCards = [
    {
        name: "Shivam Zari Center",
        location : "38 B, Tulsi Bagh",
        status: "closed",
        tob: "Home Business"
    },
    {
        name: "Koms n Cakes",
        location : "200, Jaipur House, Agra",
        status: "open",
        tob: "Home Business"
    },
    {
        name: "Crafty Sides",
        location : "45, Janta Colony, ShahGanj",
        status: "closed",
        tob: "Home Business"
    },
    {
        name: "Lakshmi Srinagar",
        location : "Nagiapati, New Agra",
        status: "closed",
        tob: "Home Business"
    },
    {
        name: "Machla Ji ke Diye ",
        location : "Nagiapati, New Agra",
        status: "open",
        tob: "Home Business"
    }
];

export default republicCards ;