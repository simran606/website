import React from 'react';
import '../../css/republic.css';

class Republic extends React.Component{

    // constructor(){
    //     super();
    // }

    render(props){
        return(

            <div className="republicDiv">

                  <div className="column">
                      
                          <h3>{this.props.name}</h3>
                          <h5>{this.props.location}</h5>
                          <p>{this.props.status}</p>
                          <p className="tob">{this.props.tob}</p>
                      
                  </div>

            </div>

      

        );
    }
}

export default Republic;