import React from 'react';
import '../css/signup.css';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

class SignUp extends React.Component{

    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="signDiv">
            <h1>Enter Your Details</h1>
                <Form>
                     <Form.Group controlId="formBasicName">
                          <Form.Control type="email" placeholder="Name" />
                     </Form.Group>

                     <Form.Group controlId="formBasicNumber">
                          <Form.Control type="password" placeholder="Mobile Number" />
                     </Form.Group>

                     <Form.Group controlId="formBasicNumber">
                          <Form.Control type="password" placeholder="Mobile Number" />
                     </Form.Group>

                     <Form.Group controlId="formBasicNumber">
                          <Form.Control type="password" placeholder="Mobile Number" />
                     </Form.Group>

                     <Form.Group controlId="formBasicNumber">
                          <Form.Control type="password" placeholder="Mobile Number" />
                     </Form.Group>

                     <Form.Group controlId="formBasicText">
                          <Form.Control type="password" placeholder="Address" />
                     </Form.Group>

                    <Button variant="primary" type="submit">
                           CONFIRM ✓
                    </Button>

                </Form>
            </div>
        );
    }
}

export default SignUp;