import React from 'react';
import Button from 'react-bootstrap/Button';
import '../../css/addItems.css';
import NavMenuCart from './NavMenuCart';
import Footer from '../footer';
import addCards from './addCards';
import AddItems from './addItems';

class ShoppingCart extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            name:'React',
            cart:[]
        };
    }

    handleAddFunc(addCards){

        const extprIn = this.state.cart.findIndex((item) => item.id === addCards.id);

        if(extprIn.length >= 0){

            const cartprs = this.state.cart.slice();

            const extpr = cartprs[extprIn];

            const updatedUnitspr = {
                ...extpr,
                units: extpr.units + addCards.units
            };

            cartprs[extprIn] = updatedUnitspr;

            this.setState({
                cart: cartprs
            });
        }

        else{
            this.setState({
                cart: [...this.state.cart, addCards]
            });
        }
    }

    render(){
        return(
            <div>
            <NavMenuCart />

            <div className = "shopName"> 
            <h2>Shivam Zari Center</h2>
            <p>Address : 38 B, Tulsi Bagh, Dayal Bagh- 282005</p>
            <h6>Phone : 8451369856</h6>
            <h6>Delivery Charges : ₹120</h6>
            </div>
            <Button  variant="primary" type="submit">
                           CHECK LOCATION
            </Button>

            

            <div className="cartDiv"> 
            <h1>Your Cart</h1>
            <ul>
                {
                    this.state.cart.map(c => <li>{c.nop} <br></br> units : {c.units}</li>) 
                }
            </ul>
            </div>
             

               {addCards.map( (item) => 
               <AddItems
               key={item.id} 
               {...item}
            //    imgsr={item.imgsr}
            //    nop={item.nop}
            //    qty={item.qty}
            //    price={item.price}
            //    mrp={item.mrp}
               addFunc ={this.handleAddFunc.bind(this)}
               />
               )
               }

               <Footer />
            </div>
        );
    }
}

export default ShoppingCart ;